$('#myCarousel, #myCarousel1, #myCarousel2, #myComments, #carousel').bcSwipe({ threshold: 50 });
