/*jslint browser:true, plusplus:true, vars:true */
/*jshint browser:true, jquery:true */

(function ($) {
    'use strict';

    $.lazyLoadXT.updateEvent += ' shown.bs.modal shown.bs.dropdown shown.bs.tab shown.bs.tooltip shown.bs.popover shown.bs.collapse slid.bs.carousel';
})(window.jQuery || window.Zepto || window.$);
