$(document).ready(function(){
    $('body').scrollspy({target: ".navbar"});   
});
